const DONNA_INGEST_URL = "https://donna-mcp.cp18101985.workers.dev/ingest";
const DONNA_SCHEDULE_URL = "https://donna-mcp.cp18101985.workers.dev/notes-schedule";
const DONNA_SCHEDULE_DONE_URL = "https://donna-mcp.cp18101985.workers.dev/notes-schedule/done";
const SUBSTACK_DRAFT_URL = "https://substack.com/api/v1/comment/draft";

const ENDPOINTS = {
  drafts: "https://substack.com/api/v1/feed/drafts?limit=20",
  me: "https://substack.com/api/v1/me",
  notes: (userId) => `https://substack.com/api/v1/reader/feed/profile/${userId}?types=note`,
};

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "SYNC") {
    handleSync(message.key, message.substackUrl).then(sendResponse);
    return true;
  }
  if (message.type === "PUSH_SCHEDULE") {
    handlePushSchedule(message.key).then(sendResponse);
    return true;
  }
});

async function handleSync(donnaKey, substackUrl) {
  try {
    const cookie = await getSubstackCookie();
    if (!cookie) {
      return { ok: false, error: "Not logged into Substack — open substack.com and log in first" };
    }

    const draftsData = await substackFetch(ENDPOINTS.drafts, cookie);
    if (draftsData === null) {
      return { ok: false, error: "Your Substack session has expired — open substack.com and log in again" };
    }
    if (!draftsData?.drafts) {
      return { ok: false, error: "Could not read Substack drafts — try logging into substack.com again" };
    }

    let userId = draftsData.drafts[0]?.user_id;

    if (!userId) {
      const meData = await substackFetch(ENDPOINTS.me, cookie);
      userId = meData?.id;
    }

    if (!userId) {
      return { ok: false, error: "Could not identify your Substack account — try logging into substack.com again" };
    }

    const notesData = await substackFetch(ENDPOINTS.notes(userId), cookie);

    let essays = [];
    if (substackUrl) {
      try {
        const base = substackUrl.replace(/\/$/, "");
        const essaysData = await fetch(`${base}/api/v1/posts?sort=new&limit=10`);
        if (essaysData.ok) {
          const json = await essaysData.json();
          essays = (json || []).map(p => ({
            id: p.id,
            title: p.title,
            subtitle: p.subtitle || "",
            date: (p.post_date || p.publishedAt || "").slice(0, 10),
            type: p.audience === "paid" ? "paid" : "free",
            word_count: p.wordcount || null,
          }));
        }
      } catch (_) {}
    }

    const payload = {
      user_id: userId,
      drafts: draftsData.drafts.map(d => ({
        id: d.id,
        body: d.body,
        scheduled_at: d.trigger_at || null,
        created_at: d.date,
      })),
      published_notes: (notesData?.items || []).map(item => ({
        id: item.comment?.id,
        body: item.comment?.body,
        date: item.comment?.date,
        reactions: item.comment?.reaction_count ?? 0,
        restacks: item.comment?.restacks ?? 0,
      })),
      essays,
    };

    const ingestRes = await fetch(DONNA_INGEST_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${donnaKey}`,
      },
      body: JSON.stringify(payload),
    });

    if (!ingestRes.ok) {
      if (ingestRes.status === 401) {
        return { ok: false, error: "Invalid Donna API key — check the key you entered" };
      }
      return { ok: false, error: `Donna server error (${ingestRes.status}) — try again` };
    }

    return { ok: true };

  } catch (err) {
    return { ok: false, error: err.message };
  }
}

async function substackFetch(url, cookie) {
  const res = await fetch(url, {
    headers: { "Cookie": `substack.sid=${cookie}` },
  });
  if (res.status === 401 || res.status === 403) return null;
  if (!res.ok) return null;
  return res.json();
}

async function handlePushSchedule(donnaKey) {
  try {
    const cookie = await getSubstackCookie();
    if (!cookie) return { ok: false, error: "Not logged into Substack — open substack.com and log in first" };

    const schedRes = await fetch(DONNA_SCHEDULE_URL, {
      headers: { "Authorization": `Bearer ${donnaKey}` },
    });
    if (!schedRes.ok) {
      if (schedRes.status === 401) return { ok: false, error: "Invalid Donna API key, or your subscription is not active" };
      return { ok: false, error: `Could not fetch schedule (${schedRes.status})` };
    }

    const { notes: queued = [], expired = 0 } = await schedRes.json();
    const expiredMsg = expired ? ` ${expired} skipped because their time had passed.` : "";

    // Remember what this browser already pushed, so a quick second click never posts duplicates.
    const { pushedNotes = {} } = await chrome.storage.local.get("pushedNotes");
    const dayAgo = Date.now() - 24 * 60 * 60 * 1000;
    for (const id of Object.keys(pushedNotes)) if (pushedNotes[id] < dayAgo) delete pushedNotes[id];
    const notes = queued.filter(n => !pushedNotes[n.id]);

    if (notes.length === 0) return { ok: true, message: `Nothing new to push. Approve notes with Donna in Claude first.${expiredMsg}` };

    let pushed = 0;
    let failed = 0;
    let unconfirmed = 0;

    for (const note of notes) {
      const bodyJson = textToBodyJson(note.text);
      const res = await fetch(SUBSTACK_DRAFT_URL, {
        method: "POST",
        credentials: "include",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          bodyJson,
          replyMinimumRole: "everyone",
          surface: "feed",
          tabId: "subscribed",
          trigger_at: note.trigger_at,
        }),
      });
      if (!res.ok) { failed++; continue; }
      pushed++;

      // Record each note the moment it lands, so an interrupted run never repeats it.
      pushedNotes[note.id] = Date.now();
      await chrome.storage.local.set({ pushedNotes });
      const done = await fetch(DONNA_SCHEDULE_DONE_URL, {
        method: "POST",
        headers: { "Authorization": `Bearer ${donnaKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({ ids: [note.id] }),
      }).catch(() => null);
      if (!done?.ok) unconfirmed++;
    }

    const failedMsg = failed ? ` ${failed} failed and stay with Donna; click again to retry them.` : "";
    const unconfirmedMsg = unconfirmed ? ` Donna could not confirm ${unconfirmed} of them; check your Substack drafts before pushing from another browser.` : "";
    return { ok: true, message: `${pushed} of ${notes.length} notes scheduled in Substack drafts.${failedMsg}${unconfirmedMsg}${expiredMsg}` };

  } catch (err) {
    return { ok: false, error: err.message };
  }
}

function textToBodyJson(text) {
  const paragraphs = text.split("\n").filter(line => line.trim() !== "");
  return {
    type: "doc",
    attrs: { schemaVersion: "v1", title: null },
    content: paragraphs.map(line => ({
      type: "paragraph",
      content: [{ type: "text", text: line }],
    })),
  };
}

async function getSubstackCookie() {
  return new Promise((resolve) => {
    chrome.cookies.get({ url: "https://substack.com", name: "substack.sid" }, (cookie) => {
      resolve(cookie?.value || null);
    });
  });
}
