const keyInput = document.getElementById("api-key");
const urlInput = document.getElementById("substack-url");
const statusDot = document.getElementById("status-dot");
const statusText = document.getElementById("status-text");
const syncBtn = document.getElementById("sync-btn");
const scheduleBtn = document.getElementById("schedule-btn");

chrome.storage.local.get(["donna_api_key", "substack_url"], ({ donna_api_key, substack_url }) => {
  if (donna_api_key) keyInput.value = donna_api_key;
  if (substack_url) urlInput.value = substack_url;
});

keyInput.addEventListener("change", () => {
  chrome.storage.local.set({ donna_api_key: keyInput.value.trim() });
});

urlInput.addEventListener("change", () => {
  chrome.storage.local.set({ substack_url: urlInput.value.trim() });
});

syncBtn.addEventListener("click", () => {
  const key = keyInput.value.trim();
  const substackUrl = urlInput.value.trim();
  if (!key) {
    setStatus("error", "Enter your Donna API key first");
    return;
  }
  setStatus("", "Syncing...");
  syncBtn.disabled = true;
  chrome.runtime.sendMessage({ type: "SYNC", key, substackUrl }, (response) => {
    syncBtn.disabled = false;
    if (response?.ok) {
      setStatus("connected", "Synced successfully");
    } else {
      setStatus("error", response?.error || "Sync failed");
    }
  });
});

scheduleBtn.addEventListener("click", () => {
  const key = keyInput.value.trim();
  if (!key) { setStatus("error", "Enter your Donna API key first"); return; }
  setStatus("", "Pushing schedule to Substack...");
  scheduleBtn.disabled = true;
  chrome.runtime.sendMessage({ type: "PUSH_SCHEDULE", key }, (response) => {
    scheduleBtn.disabled = false;
    if (response?.ok) {
      setStatus("connected", response.message);
    } else {
      setStatus("error", response?.error || "Push failed");
    }
  });
});

function setStatus(state, message) {
  statusDot.className = "dot" + (state ? " " + state : "");
  statusText.textContent = message;
}
