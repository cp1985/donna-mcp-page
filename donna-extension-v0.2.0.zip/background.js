const DONNA_INGEST_URL = "https://donna-mcp.cp18101985.workers.dev/ingest";

const ENDPOINTS = {
  drafts: "https://substack.com/api/v1/feed/drafts?limit=20",
  me: "https://substack.com/api/v1/me",
  notes: (userId) => `https://substack.com/api/v1/reader/feed/profile/${userId}?types=note`,
};

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "SYNC") {
    handleSync(message.key, message.substackUrl).then(sendResponse);
    return true;
  }
});

async function handleSync(donnaKey, substackUrl) {
  try {
    const cookie = await getSubstackCookie();
    if (!cookie) {
      return { ok: false, error: "Not logged into Substack — open substack.com and log in first" };
    }

    const draftsData = await substackFetch(ENDPOINTS.drafts, cookie);
    if (draftsData === null) {
      return { ok: false, error: "Your Substack session has expired — open substack.com and log in again" };
    }
    if (!draftsData?.drafts) {
      return { ok: false, error: "Could not read Substack drafts — try logging into substack.com again" };
    }

    let userId = draftsData.drafts[0]?.user_id;

    if (!userId) {
      const meData = await substackFetch(ENDPOINTS.me, cookie);
      userId = meData?.id;
    }

    if (!userId) {
      return { ok: false, error: "Could not identify your Substack account — try logging into substack.com again" };
    }

    const notesData = await substackFetch(ENDPOINTS.notes(userId), cookie);

    let essays = [];
    if (substackUrl) {
      try {
        const base = substackUrl.replace(/\/$/, "");
        const essaysData = await fetch(`${base}/api/v1/posts?sort=new&limit=10`);
        if (essaysData.ok) {
          const json = await essaysData.json();
          essays = (json || []).map(p => ({
            id: p.id,
            title: p.title,
            subtitle: p.subtitle || "",
            date: (p.post_date || p.publishedAt || "").slice(0, 10),
            type: p.audience === "paid" ? "paid" : "free",
            word_count: p.wordcount || null,
          }));
        }
      } catch (_) {}
    }

    const payload = {
      user_id: userId,
      drafts: draftsData.drafts.map(d => ({
        id: d.id,
        body: d.body,
        scheduled_at: d.trigger_at || null,
        created_at: d.date,
      })),
      published_notes: (notesData?.items || []).map(item => ({
        id: item.comment?.id,
        body: item.comment?.body,
        date: item.comment?.date,
        reactions: item.comment?.reaction_count ?? 0,
        restacks: item.comment?.restacks ?? 0,
      })),
      essays,
    };

    const ingestRes = await fetch(DONNA_INGEST_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${donnaKey}`,
      },
      body: JSON.stringify(payload),
    });

    if (!ingestRes.ok) {
      if (ingestRes.status === 401) {
        return { ok: false, error: "Invalid Donna API key — check the key you entered" };
      }
      return { ok: false, error: `Donna server error (${ingestRes.status}) — try again` };
    }

    return { ok: true };

  } catch (err) {
    return { ok: false, error: err.message };
  }
}

async function substackFetch(url, cookie) {
  const res = await fetch(url, {
    headers: { "Cookie": `substack.sid=${cookie}` },
  });
  if (res.status === 401 || res.status === 403) return null;
  if (!res.ok) return null;
  return res.json();
}

async function getSubstackCookie() {
  return new Promise((resolve) => {
    chrome.cookies.get({ url: "https://substack.com", name: "substack.sid" }, (cookie) => {
      resolve(cookie?.value || null);
    });
  });
}
